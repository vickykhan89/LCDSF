function [pc, parent, child, unsure, ntime] = Identify(path)
 pcdata = importdata(path);
 [row,column] = size(pcdata);
 pc = [];
 parent =[];
 child = [];
 unsure =[];
  for i = 1 : row-1
      if i == 1
%           disp('1');
          for j = 1 : column
            pc =[pc, floor(pcdata(i,j))];
          end
      elseif i==2
%           disp('2');
          if pcdata(2,1) ==0
              continue;
          end
          for j = 1 : column
              if ~isnan(pcdata(2,j))
                parent =[parent, floor(pcdata(2,j))];
              else
                  continue;
              end
          end
       elseif i==3
%            disp('3');
           if pcdata(3,1) ==0
              continue;
          end
          for j = 1 : column
              if ~isnan(pcdata(i,j))
                child =[child, floor(pcdata(3,j))];
              else
                  continue;
              end
          end
        elseif i==4
%             disp('4');
           if pcdata(4,1) ==0
              continue;
          end
          for j = 1 : column
              if ~isnan(pcdata(i,j))
                unsure =[unsure, floor(pcdata(4,j))];
              else
                  continue;
              end
          end
      end
  end
 ntime = pcdata(5,1);