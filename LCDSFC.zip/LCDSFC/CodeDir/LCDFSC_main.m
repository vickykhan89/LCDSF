clear all;
alpha = 0.01; %  significance level
%target = 23;
%test = 'g2';
for size_i = 1 
    if size_i == 1
        size = '5000'; % 5000 data examples
    end
    
    for loop_i = 1
        if loop_i == 1
           dataset='alarm';    dataset2='Alarm1'; % dataset 
        end

        num = 1; % Note that 10 data sets are used in the paper. 
        data = cell(1,num);
        benchmark = pwd;
        addpath(genpath(benchmark));
        for i = 1:num
    
            data_str = [benchmark,'/data/',dataset, '_data/',dataset2,'_s',num2str(size),'_v',num2str(i),'.txt'];
            data{i} = importdata(data_str)+1;
        end
        graph_str = [benchmark,'/data/',dataset, '_data/',dataset2,'_graph.txt'];
        graph_data = importdata(graph_str);
        [trueMB,trueP,trueC,truePC,trueSP,p]= STA(graph_data);
        disp('LCDFSC')
        fprintf('%s_%s\n\n',dataset,size);
        %data = cell2mat(data);
        %[pc, time] = osfs_d(data,target,alpha, test);
        [mean_F1] = evaluation_LCDFSC(data,truePC,trueP,trueC,alpha,dataset);
    end
end

        