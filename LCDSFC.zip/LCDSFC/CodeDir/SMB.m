%function [MB, pc, Spouse, ntime] = FSCMB(data, target_feature, alpha, ns, p)
function [MB, pc, parent, child, unsure, SpouseY, ntest, ntime] = FSCMB(data, target_feature, alpha, ns, p)
%function  [pc,time,CSP]  = FSCMB(data,target_feature,alpha,test)

% Input :
%       Data is the data matrix, NbVar columns * N rows
%       target is the index of target variable
%       alpha is the significance level
%       ns = max(data)
%       p is the number of variables
%       maxk is the caidinal of max subset
%output:
%       MB is the parents, children and spouses of the target
%       pc is the parents and children of the target
%       parent is the parents of the target
%       children is the children of the target
%       unsure is the undistinguished PC variables of the target
%       SpouseY is the set that contains the  spouse sets of all PC variables 
%       ntest is the number of conditional independence
%       time is the runtime of the algorithm

    start = tic;
    ntest = 0;
    Spouse = [];
    test = 'g2';
    %----my add----%
    sep=[];
    PC=[];
    pc=[];
    SS=[];
    ci=[];
    cind=[];
    start=tic;
    [n,numFeatures] = size(data);
    CSP=cell(1,numFeatures);
    ccond=cell(1,numFeatures);
    CPC=cell(1,numFeatures);
    ns=max(data);
    selected_features=[];
    selected_features1=[];
    
for i = 1:numFeatures 
    if i==target_feature
        continue;
    end
    %for very sparse data
    n1=sum(data(:,i));
    if n1==0
        continue;
    end 
    stop=0;
    [CI,SS]=my_cond_indep_chisquare(data,i,target_feature,[],test,alpha, ns);
    if CI==1 
            cind=[cind,i];
            ci=i;
            ccond{i}=[];
    else
       stop=1;
   end
   if stop  
        if ~isempty(selected_features)
            [CI,mcond]=compter_dep_2(selected_features,i,target_feature,3,1, alpha, test,data);
        end              
        if CI==0    
            selected_features=[selected_features,i];      
            p2=length(selected_features);
            selected_features1=selected_features;
            if ~isempty(p2)
                 for j=1:p2
                     P=eq(i,selected_features(j));
                     if P==0
                        b=setdiff(selected_features1,selected_features(j), 'stable');
                        if ~isempty(b)
                            [CI3,SS1]=optimal_compter_dep_2(b,selected_features(j),target_feature,3, 1, alpha, test,data);
                             if CI3==1   
                            
                                 selected_features1=b;
%                                                  
                                 CSP{selected_features(j)}=[];
    %                              
                                    p2=length(selected_features1);
                                    for k=1:p2
                                        KK=ismember(selected_features1(k),CPC{selected_features(j)});
                                        KK=double(KK);
                                        if KK==0
                                            SS=[SS1,selected_features1(k)];
                                            SS=unique(SS);
                                            CI=my_cond_indep_chisquare(data,selected_features(j),target_feature,SS,test,alpha, ns);  
                                            if CI==0   
                                                     CSP{selected_features1(k)}=[CSP{selected_features1(k)},selected_features(j)];
                                                     csp12=CSP{selected_features1(k)};
                                                     nn=length(csp12);
                                                     csp=csp12;
                                                     if ~isempty(nn)
                                                        for a=1:nn 
                                                            
                                                            m1=[selected_features1,csp];
                                                            m1=setdiff(m1,csp12(a),'stable');
                                                            [CI,S,dep]=optimal_compter_dep_21(m1,csp12(a),target_feature,3, 1, alpha, test,data,selected_features1(k));
                                                            if CI==1 || isnan(dep) 
                                                                    CSP{selected_features1(k)}(CSP{selected_features1(k)}==csp12(a))=[];                               
                                                                    csp=CSP{selected_features1(k)};
                                                            end
                                                        end
                                                     end                                            
%                                                  end
                                            end
                                        end
                                    end
                                    CPC{selected_features(j)}=[CPC{selected_features(j)},selected_features1];
                            end
                        end                       
                     end 
               end
            end

        else 
                cind=[cind,i];
                ccond{i}=mcond;
                ci=i;
        end
   end
   pc=selected_features1;  

    if ~isempty(pc) && ~isempty(cind)      
      GG=max(pc);
      if ci<GG
         plength1=length(cind);
         for k1=1:plength1
             scind=[ccond{cind(k1)},GG];
             scind=unique(scind);
             CI5=my_cond_indep_chisquare(data,cind(k1),target_feature,scind,test,alpha, ns);
             if CI5==0
                 CSP{GG}=[CSP{GG},cind(k1)];
                 csp1=CSP{GG};
                 nn=length(csp1);
                 csp=csp1;
                 for b=1:nn 
                    m2=[pc,csp];
                    m2=setdiff(m2,csp1(b),'stable');
                    [CI,s,dep]=optimal_compter_dep_21(m2,csp1(b),target_feature,3,1, alpha, test,data,GG); 
                    if CI==1 || isnan(dep) 
                            CSP{GG}(CSP{GG}==csp1(b))=[];                          
                            csp=CSP{GG};                                 
                    end
                end
             end
         end
      else
         pp=length(pc);
         for e=1:pp
            scind=[ccond{ci},pc(e)];
            scind=unique(scind);
            CI6=my_cond_indep_chisquare(data,ci,target_feature,scind,test,alpha, ns);
            if CI6==0
                CSP{pc(e)}=[CSP{pc(e)},ci];
                csp1=CSP{pc(e)};
                nn=length(csp1);
                csp=csp1;
                for b=1:nn 
                    m2=[pc,csp];
                    m2=setdiff(m2,csp1(b),'stable');
                    [CI,s,dep]=optimal_compter_dep_21(m2,csp1(b),target_feature,3, 1, alpha, test,data,pc(e)); 
                    if CI==1 || isnan(dep) 
                            CSP{pc(e)}(CSP{pc(e)}==csp1(b))=[];                          
                            csp=CSP{pc(e)};
                   end
                end
            end
          end
      end
    end
%end

 
    %------------------Step4: DistinguishPC---------------------------- -------------------------------% 
    SY = cell(1,length(pc));
    for i = 1 : length(pc)
        SY{1,i} = CSP{1,pc(i)};
    end
    SpouseY = SY;
    SpouseYCheckC = SY; %used to check some children
    
    Spouse = [];
    for i = 1 : length(pc)
        CanSpY = SpouseY{1, i};
        Spouse = myunion(CanSpY, Spouse);
    end

    parent = [];
    child = [];
    unsure = [];
    for i = 1 : length(pc)
        if length(SpouseY{1, i})>0
            child = [child, pc(i)];
        end
    end

    %--------------------------------------------------------------------------------------
    % using N-structures to identify the direct effects  of a given variable
    child_two =[];%Satisfy certain conditions
    for i = 1 : length(pc)
        if length(SpouseY{1, i})==0
            if(intersect(SpouseYCheckC{1,i},Spouse))
                child_two = [child_two,pc(i)];
            end
        end
    end
    %--------------------------------------------------------------------------------------

    child_two = unique(child_two);
    child = [child, child_two];
    child = unique(child);
    parent = [];

    unsure = mysetdiff(pc, child);%mysetdiff(CanPC, child);

    % using Lemma 1 (a) to identify the direct causes  of the target  variable
    for i = 1 : length(unsure)
        for j = i+1 : length(unsure)
            ntest = ntest + 1;
            %[pval]=g2test_2(unsure(i), unsure(j), [], data, ns);%g2test_2(unsure(i), unsure(j), [], Data, ns); 
            [pval]=my_cond_indep_chisquare(data,unsure(i),unsure(j),[],test,alpha, ns);
            if isnan(pval)
                CI = 0;
            else
               if pval <= alpha
                    CI = 0;
               else
                    CI = 1;
                    ntest = ntest + 1;
                    %[pval]=g2test_2(unsure(i), unsure(j), target_feature, data, ns);
                    [pval]=my_cond_indep_chisquare(data,unsure(i),unsure(j),target_feature,test,alpha, ns); 
                    if isnan(pval)
                        CII = 0;
                    else
                       if pval <= alpha
                          CII = 0;
                       else
                          CII = 1;
                       end
                    end
                    if CII == 0 %conditional dependence 
                        parent = [parent,[unsure(i), unsure(j)]];
                    end
               end
            end
        end
    end
    parent = unique(parent);

    % using Lemma 1 (b) to identify the direct effects  of the target  variable
    rest = mysetdiff(pc, [child,parent]);%mysetdiff(CanPC, [child,parent]);
    if ~isempty(parent)
        for i = 1 : length(rest)
            ntest = ntest + 1;
            %[pval]=g2test_2(parent(1), rest(i), [], data, ns);  %g2test_2(parent(1), rest(i), [], Data, ns);  
            [pval]=my_cond_indep_chisquare(data,parent(1),rest(i),[],test,alpha, ns);
            if isnan(pval)
                CI = 0;
            else
               if pval <= alpha
                    CI = 0;
               else
                    CI = 1;
               end
            end
            if CI==0
                ntest = ntest + 1;
                %[pval]=g2test_2(parent(1), rest(i), target_feature, data, ns); %g2test_2(parent(1), rest(i), target, Data, ns); 
                [pval]=my_cond_indep_chisquare(data,parent(1),rest(i),target_feature,test,alpha, ns);
                if isnan(pval)
                    CII = 0;
                else
                   if pval <= alpha
                      CII = 0;
                   else
                      CII = 1;
                   end
                end
                if CII == 1 %conditional dependence 
                    child = [child,rest(i)];
                end
            end
        end
    end
    unsure = mysetdiff(pc, [child,parent]);%mysetdiff(CanPC, [child,parent]);
end
    PC=pc;%pc = CanPC;
    %Spouse = cell2mat(csp);%cell2mat(CSP);
    MB = [pc, Spouse];
    MB = sort(MB);
    ntime = toc(start);
end
