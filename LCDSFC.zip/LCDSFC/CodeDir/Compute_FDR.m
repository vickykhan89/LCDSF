
function [FDR]=Compute_FDR(nreverse,trueC,C,trueP,P,UN,i,p)
    G=zeros(p,p); DAG=zeros(p,p);
    G(i,trueC)=-1;    G(trueP,i)=-1;
    DAG(i,C)=-1;      DAG(P,i)=-1;
%     if length(UN) > 0
%         DAG(i,UN)=1;        DAG(UN,i)=1;
%     end
    G_Add_GTT = G + G';
% 
    diff_G=DAG-G_Add_GTT;
    false_pos = 0;
    
    [x,y]=find(diff_G==-1);
    false_pos = false_pos + length(x);
    
    if length(UN)>0
        G2=zeros(p,p); DAG2=zeros(p,p);
        G2(i,trueC)=1;   G2(trueP,i)=1;
        DAG2(i,UN)=1;  
        
        G_Add_GTT2 = G2 + G2';
        diff_G2=DAG2-G_Add_GTT2;
        [x2,y2]=find(diff_G2==1);
        false_pos = false_pos + length(x2);
    end
    
    FDR = (nreverse + false_pos)/max(length(P)+length(C)+length(UN),1);
  
    
    


% nextra = nextra - nundirected;
% for loop_i=1:length(x)
%     
%     if x(loop_i)==-1
%         continue;
%     end
%     biaozhi=0;
%     
%     if ~isempty(find(y==(x(loop_i)), 1))
%         y_index=find(y==(x(loop_i)));
%         for k=1:length(y_index)
%             if x(y_index(k))==y(loop_i)
%                 
%                 biaozhi=1;
%                 if G(x(loop_i),y(loop_i))==G(x(y_index(k)),y(y_index(k)))
%                     nextra=nextra+1;
%                 else
%                     nreverse=nreverse+1;
%                     
%                 end
%                 x(y_index(k))=-1;
%                 y(y_index(k))=-1;
%                 break;
%                 
%             end
%         end
%     end
%     if biaozhi==0
%         if G(y(loop_i),x(loop_i))==0
%             if G(x(loop_i),y(loop_i))==1
%                 nmiss=nmiss+1;
%                 
%             else
%                 nextra=nextra+1;
%                 
%             end
%         else
%             nundirected=nundirected+1;
%         end
%     end
% end



%%myadd---%%
% G_Add_GTT = G + G';
% 
% diff_G=G-DAG;






